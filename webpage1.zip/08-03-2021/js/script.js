/*header js start*/

$(document).ready(function () {
 
  $("[data-trigger]").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    var offcanvas_id = $(this).attr("data-trigger");
    $(offcanvas_id).toggleClass("show");
    $("body").toggleClass("offcanvas-active");
    $(".screen-overlay").toggleClass("show");
  });

  $(document).on("keydown", function (event) {
    if (event.keyCode === 27) {
      $(".mobile-offcanvas").removeClass("show");
      $("body").removeClass("overlay-active");
    }
  });

  $(".btn-close, .screen-overlay").click(function (e) {
    $(".screen-overlay").removeClass("show");
    $(".mobile-offcanvas").removeClass("show");
    $("body").removeClass("offcanvas-active");
  });
}); 

/*header js end*/


/*header scroll add class js start*/
$(window).scroll(function() {
    if ($(this).scrollTop() > 50){  
        $('header').addClass("sticky");
    }
    else{
        $('header').removeClass("sticky");
    }
});
/*header scroll add class js end*/


/*how it works filter js start*/

$(document).ready(function() {
      var $gallery = $('#gallery');
      var $boxes = $('.revGallery-anchor');
      $boxes.hide(); 

      $gallery.imagesLoaded( {background: true}, function() {
        $boxes.fadeIn();

        $gallery.isotope({
          // options
          sortBy : 'original-order',
          layoutMode: 'fitRows',
          itemSelector: '.revGallery-anchor',
          stagger: 30,
        });
      }); 

      $('button').on( 'click', function() {
        var filterValue = $(this).attr('data-filter');
          $('#gallery').isotope({ filter: filterValue });
          $gallery.data('lightGallery').destroy(true);
          $gallery.lightGallery({
              selector: filterValue.replace('*','')
          });
      });
});

$(document).ready(function() {
          $("#gallery").lightGallery({
            
}); 
      });

//button active mode
$('.button').click(function(){
    $('.button').removeClass('is-checked');
    $(this).addClass('is-checked');
});


//CSS Gram Filters on Mouse enter
$("#gallery a .nak-gallery-poster").addClass("inkwell");

$("#gallery a").on({
  mouseenter : function() {
      $(this).find(".nak-gallery-poster").removeClass("inkwell").addClass("walden");
  },
  mouseleave : function() {
      $(this).find(".nak-gallery-poster").removeClass("walden").addClass("inkwell");
  }
});
/*how it works filter js end*/
$(document).ready(function() {
  $("#wave_img").length&&$("#wave_img").wavify({height:100,bones:3,amplitude:50,color:"#fff",speed:.25});
}); 

